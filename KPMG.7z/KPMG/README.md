# KPMG-Virtual-Internship

This repository contains solutions to the 3 different tasks that must be performed during the data analytics virtual internship provided by **KPMG** via **Forage**.

## Intership Description
I) **TASK 1** - _Data Quality Assessment_

    Assessment of data quality and completeness in preparation for analysis. 

II) **TASK 2** - _Data Insights_

    Targeting high value customers based on customer demographics and attributes. 

III) **TASK 3** - _Data Insights and Presentation_

     Using visualisations to present insights.

